package cn.jsprun.foreg.vo.wap;
public class SearchVO extends WithFooterAndHead {
	private String sid = null;
	public String getSid() {
		return sid;
	}
	public void setSid(String sid) {
		this.sid = sid;
	}
}
