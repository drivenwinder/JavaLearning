package cn.jsprun.foreg.vo.wap;
public class HeaderVO {
	private String title = null;
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
}
