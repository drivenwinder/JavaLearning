package cn.jsprun.foreg.vo.statistic;
public class CompositorInfo {
		private String compositorName;
		private String compositorSign;
		private String compositorNum;
		public String getCompositorSign() {
			return compositorSign;
		}
		public void setCompositorSign(String compositorId) {
			this.compositorSign = compositorId;
		}
		public String getCompositorName() {
			return compositorName;
		}
		public void setCompositorName(String compositorName) {
			this.compositorName = compositorName;
		}
		public String getCompositorNum() {
			return compositorNum;
		}
		public void setCompositorNum(String compositorNum) {
			this.compositorNum = compositorNum;
		}
}
