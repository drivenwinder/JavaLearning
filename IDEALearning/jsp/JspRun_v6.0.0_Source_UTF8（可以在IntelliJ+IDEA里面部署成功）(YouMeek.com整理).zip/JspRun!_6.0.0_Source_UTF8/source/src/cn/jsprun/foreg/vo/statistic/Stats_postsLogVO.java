package cn.jsprun.foreg.vo.statistic;
public class Stats_postsLogVO {
	private Stats_navbarVO navbar = new Stats_navbarVO();
	private SubPostlog subPostLog = new SubPostlog();
	public Stats_navbarVO getNavbar() {
		return navbar;
	}
	public SubPostlog getSubPostLog() {
		return subPostLog;
	}
}
