package cn.jsprun.foreg.vo.magic;
public class Magic_market_prepareoperationVO extends Magic_navbarVO{
	private String operation;
	private String magicMarketId;
	private String magicName;
	private String magicInfo;
	private String magicPrice;
	private String magicUtil;
	private String magicWeight;
	private String magicStock;
	private String imageName;
	public String getImageName() {
		return imageName;
	}
	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
	public Magic_market_prepareoperationVO(){
	}
	public String getMagicInfo() {
		return magicInfo;
	}
	public void setMagicInfo(String magicInfo) {
		this.magicInfo = magicInfo;
	}
	public String getMagicName() {
		return magicName;
	}
	public void setMagicName(String magicName) {
		this.magicName = magicName;
	}
	public String getMagicPrice() {
		return magicPrice;
	}
	public void setMagicPrice(String magicPrice) {
		this.magicPrice = magicPrice;
	}
	public String getMagicStock() {
		return magicStock;
	}
	public void setMagicStock(String magicStock) {
		this.magicStock = magicStock;
	}
	public String getMagicUtil() {
		return magicUtil;
	}
	public void setMagicUtil(String magicUtil) {
		this.magicUtil = magicUtil;
	}
	public String getMagicWeight() {
		return magicWeight;
	}
	public void setMagicWeight(String magicWeight) {
		this.magicWeight = magicWeight;
	}
	public String getOperation() {
		return operation;
	}
	public void setOperation(String operation) {
		this.operation = operation;
	}
	public String getMagicMarketId() {
		return magicMarketId;
	}
	public void setMagicMarketId(String magicMarketId) {
		this.magicMarketId = magicMarketId;
	}
}
