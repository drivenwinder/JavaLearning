package cn.jsprun.dao;
import java.util.List;
import cn.jsprun.domain.Promotions;
public interface PromotionsDao {
	public List<Promotions> getAllPromotions();
}
