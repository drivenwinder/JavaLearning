package cn.jsprun.foreg.vo.archiver;
public class WithHeaderAndFoot {
	private Header_inc header = null;
	private Foot_inc footer = null;
	public Header_inc getHeader() {
		return header;
	}
	public void setHeader(Header_inc header) {
		this.header = header;
	}
	public Foot_inc getFooter() {
		return footer;
	}
	public void setFooter(Foot_inc footer) {
		this.footer = footer;
	}
}
