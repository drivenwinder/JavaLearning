package cn.jsprun.foreg.vo.wap;
public class PmVO extends WithFooterAndHead {
	private String num_unread = null;
	private String num_all = null;
	public String getNum_unread() {
		return num_unread;
	}
	public void setNum_unread(String num_unread) {
		this.num_unread = num_unread;
	}
	public String getNum_all() {
		return num_all;
	}
	public void setNum_all(String num_all) {
		this.num_all = num_all;
	}
}
