package cn.jsprun.foreg.vo.wap;
public interface ThreadInfo {
	public String getTid() ;
	public void setTid(String tid) ;
	public String getNumber() ;
	public void setNumber(String number) ;
	public String getSubject() ;
	public void setSubject(String subject) ;
	public String getPrefix() ;
	public void setPrefix(String prefix) ;
	public String getAuthor() ;
	public void setAuthor(String author) ;
	public String getReplies() ;
	public void setReplies(String replies) ;
	public String getViews() ;
	public void setViews(String views) ;
}
