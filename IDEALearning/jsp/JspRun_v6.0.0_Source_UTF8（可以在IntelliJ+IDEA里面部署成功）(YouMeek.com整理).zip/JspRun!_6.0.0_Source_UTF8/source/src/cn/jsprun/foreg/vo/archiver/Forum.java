package cn.jsprun.foreg.vo.archiver;
public class Forum {
	private String fid = null;
	private String name = null;
	public String getFid() {
		return fid;
	}
	public void setFid(String fid) {
		this.fid = fid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
}
