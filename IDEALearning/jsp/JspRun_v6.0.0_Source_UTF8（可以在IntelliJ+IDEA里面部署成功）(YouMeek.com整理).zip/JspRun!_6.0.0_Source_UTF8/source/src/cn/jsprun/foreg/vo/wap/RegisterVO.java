package cn.jsprun.foreg.vo.wap;
public class RegisterVO extends WithFooterAndHead {
}
