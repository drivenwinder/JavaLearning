package cn.jsprun.foreg.vo.topicadmin;
public class BaseVOWithSpareCheckBox extends BaseVO {
	private boolean showUnchain;
	public boolean isShowUnchain() {
		return showUnchain;
	}
	public void setShowUnchain(boolean showUnchain) {
		this.showUnchain = showUnchain;
	}
}
