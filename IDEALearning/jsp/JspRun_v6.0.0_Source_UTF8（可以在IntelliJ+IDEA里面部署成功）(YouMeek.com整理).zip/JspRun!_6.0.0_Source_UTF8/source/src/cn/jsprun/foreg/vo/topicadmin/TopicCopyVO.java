package cn.jsprun.foreg.vo.topicadmin;
public class TopicCopyVO extends TopicPublicVO {
	private String selectContent = null;
	public String getSelectContent() {
		return selectContent;
	}
	public void setSelectContent(String selectContent) {
		this.selectContent = selectContent;
	}
}
