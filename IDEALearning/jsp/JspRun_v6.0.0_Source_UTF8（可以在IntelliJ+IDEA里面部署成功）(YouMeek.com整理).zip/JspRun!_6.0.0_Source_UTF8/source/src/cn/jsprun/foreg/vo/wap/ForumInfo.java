package cn.jsprun.foreg.vo.wap;
public interface ForumInfo {
	String getFid();
	void setFid(String fid);
	String getName();
	void setName(String name);
}
