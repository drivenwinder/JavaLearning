package cn.jsprun.foreg.vo.topicadmin;
public class ToTopAndEliteVO extends BaseVOWithSpareCheckBox {
	private String level;
	private Integer stickPurview;
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public Integer getStickPurview() {
		return stickPurview;
	}
	public void setStickPurview(Integer stickPurview) {
		this.stickPurview = stickPurview;
	}
}
