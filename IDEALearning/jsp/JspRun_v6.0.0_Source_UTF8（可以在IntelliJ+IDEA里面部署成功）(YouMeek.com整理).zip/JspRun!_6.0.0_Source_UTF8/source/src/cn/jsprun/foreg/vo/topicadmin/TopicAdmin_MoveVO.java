package cn.jsprun.foreg.vo.topicadmin;
import java.util.ArrayList;
import java.util.List;
public class TopicAdmin_MoveVO extends BaseVO {
	private String selectContent = null;
	public String getSelectContent() {
		return selectContent;
	}
	public void setSelectContent(String selectContent) {
		this.selectContent = selectContent;
	}
}
