package cn.jsprun.foreg.vo.topicadmin;
public class CloseOrOpenTopicVO extends BaseVO {
	private String close;
	public String getClose() {
		return close;
	}
	public void setClose(String close) {
		this.close = close;
	}
}
