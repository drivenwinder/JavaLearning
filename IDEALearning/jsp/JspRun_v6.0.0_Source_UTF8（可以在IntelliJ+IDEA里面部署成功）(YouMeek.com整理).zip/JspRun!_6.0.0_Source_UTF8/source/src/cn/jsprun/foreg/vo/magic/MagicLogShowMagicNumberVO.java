package cn.jsprun.foreg.vo.magic;
public class MagicLogShowMagicNumberVO extends MagicLogBaseVO {
	private String magicNum;
	public MagicLogShowMagicNumberVO(){
	}
	public String getMagicNum() {
		return magicNum;
	}
	public void setMagicNum(String magicNum) {
		this.magicNum = magicNum;
	}
}
